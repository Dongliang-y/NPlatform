﻿/**************************************************************
 *  Filename:    CommandBase.cs
 *  Copyright:    Co., Ltd.
 *
 *  Description: CommandBase ClassFile.
 *
 *  @author:     Dongliang Yi
 *  @version     2022/2/11 10:45:24  @Reviser  Initial Version
 **************************************************************/
using NPlatform.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NPlatform.Commands
{
    /// <summary>
    /// 命令对象基类，基于Dto实现。
    /// </summary>
    public abstract class CommandBase : Dto.BaseDto, ICommand
    {
        private ValidationResult _ValidationResult;
        public CommandBase(CType commandType, string aggregateId)
        {
            this.CommandType = commandType;
            this.CreateTime = DateTime.Now;
            AggregateId = aggregateId;
        }

        public CType CommandType { get; set; }
        public string AggregateId { get; set; }

        /// <summary>
        /// 获取校验结果
        /// </summary>
        public virtual ValidationResult ValidationResult
        {
            get
            {
                return _ValidationResult;
            }
        }

        /// <summary>
        /// 设置校验结果
        /// </summary>
        /// <param name="result"></param>
        protected virtual void SetValidationResult(ValidationResult result)
        {
            _ValidationResult = result;
        }

        public abstract bool IsValid();
    }
}
