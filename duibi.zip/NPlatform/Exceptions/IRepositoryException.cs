﻿/********************************************************************************

** auth： DongliangYi

** date： 2016/8/31 10:47:08

** desc： 尚未编写描述

** Ver.:  V1.0.0

*********************************************************************************/

namespace NPlatform.Repositories.Exceptions
{
    /// <summary>
    /// 仓储一场接口
    /// </summary>
    public interface IRepositoryException : INPlatformException
    {
    }
}