﻿namespace NPlatform.Result
{ 
    /// <summary>
    /// 树Result
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ITreeResult<T> : INPResult 
    { }
}
