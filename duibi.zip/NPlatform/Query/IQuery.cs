﻿/**************************************************************
 *  Filename:    IQuery.cs
 *  Copyright:    Co., Ltd.
 *
 *  Description: IQuery ClassFile.
 *
 *  @author:     Dongliang Yi
 *  @version     2022/2/11 9:26:55  @Reviser  Initial Version
 **************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NPlatform.Query
{
    /// <summary>
    /// 查询条件
    /// </summary>
    public interface IQuery
    {
    }
}
