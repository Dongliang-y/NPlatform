﻿/**************************************************************
 *  Filename:    ICommand.cs
 *  Copyright:    Co., Ltd.
 *
 *  Description: ICommand ClassFile.
 *
 *  @author:     Dongliang Yi
 *  @version     2022/2/11 10:07:02  @Reviser  Initial Version
 **************************************************************/
using NPlatform.Dto;
using NPlatform.Enums;
using NPlatform.Result;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NPlatform
{

    public interface ICommand:MediatR.IRequest<INPResult>,IDto
    {
        public CType CommandType { get; set; }

        /// <summary>
        /// 聚合ID
        /// </summary>
        public string AggregateId { get; set; }

        //DTO绑定验证，使用Fluent API来实现
        public ValidationResult ValidationResult { get;}


        //实现Command抽象类的DTO数据验证
        public bool IsValid();
    }
}
