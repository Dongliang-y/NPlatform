﻿/**************************************************************
 *  Filename:    IProfile.cs
 *  Copyright:    Co., Ltd.
 *
 *  Description: IProfile ClassFile.
 *
 *  @author:     Dongliang Yi
 *  @version     2021/12/21 9:25:26  @Reviser  Initial Version
 **************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NPlatform.AutoMap
{
    /// <summary>
    /// AutoMapper IProfile
    /// </summary>
    public interface IProfile
    {
    }
}
