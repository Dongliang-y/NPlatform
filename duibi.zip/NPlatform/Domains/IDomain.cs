﻿#region << 版 本 注 释 >>

/*----------------------------------------------------------------
* 项目名称 ：NPlatform.Domain
* 类 名 称 ：IDomain
* 类 描 述 ：
* 命名空间 ：NPlatform.Domain
* CLR 版本 ：4.0.30319.42000
* 作    者 ：DongliangYi
* 创建时间 ：2018-11-19 17:10:39
* 更新时间 ：2018-11-19 17:10:39
* 版 本 号 ：v1.0.0.0
//----------------------------------------------------------------*/

#endregion

namespace NPlatform.Domains
{
    /// <summary>
    /// 领域根接口
    /// </summary>
    public interface IDomain
    {
    }
}