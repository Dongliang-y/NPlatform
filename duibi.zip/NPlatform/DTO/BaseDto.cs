﻿/********************************************************************************

** auth： DongliangYi

** date： 2016/8/29 10:08:46

** desc：Dto接口 基类

** Ver.:  V1.0.0

*********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NPlatform.Dto;
using NPlatform.Result;

namespace NPlatform.Dto
{
    /// <summary>
    /// Dto 基类
    /// </summary>
    public class BaseDto : IDto
    {
        public DateTime CreateTime { get;protected set; }
    }
}
