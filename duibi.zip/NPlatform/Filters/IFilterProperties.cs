﻿#region << 版 本 注 释 >>

/*----------------------------------------------------------------
* 项目名称 ：NPlatform.Filters
* 项目描述 ：
* 类 名 称 ：IEntityFilter
* 类 描 述 ：
* 所在的域 ：LDY
* 命名空间 ：NPlatform.Filters
* 机器名称 ：LDY 
* CLR 版本 ：4.0.30319.42000
* 作    者 ：DongliangYi
* 创建时间 ：2018-12-28 9:56:36
* 更新时间 ：2018-12-28 9:56:36
* 版 本 号 ：v1.0.0.0
*******************************************************************
* Copyright @ DongliangYi 2018. All rights reserved.
*******************************************************************
//----------------------------------------------------------------*/

#endregion

namespace NPlatform.Filters
{
    /// <summary>
    /// 过滤规范属性
    /// </summary>
    public interface IFilterProperties
    {
    }
}