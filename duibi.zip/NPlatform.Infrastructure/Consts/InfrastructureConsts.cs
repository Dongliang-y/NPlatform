﻿namespace NPlatform
{
    using System.ComponentModel;

    /// <summary>
    /// 基础设施的Consts
    /// </summary>
    public static class InfrastructureConsts
    {
        internal static string APPLICATIONLISTID = "ApplicationLog"; // 应用日志缓存标识
    }
}