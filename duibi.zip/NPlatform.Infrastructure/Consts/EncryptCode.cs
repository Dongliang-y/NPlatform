﻿/*************************************************************************************
  * CLR版本：       4.0.30319.42000
  * 类 名 称：       EncryptCode
  * 机器名称：       DESKTOP-E6DEUVR
  * 命名空间：       NPlatform.Infrastructure.Consts
  * 文 件 名：       EncryptCode
  * 创建时间：       2019-12-13 15:52:03
  * 作    者：          xxx
  * 说   明：。。。。。
  * 修改时间：
  * 修 改 人：
*************************************************************************************/
using System;
using System.Collections.Generic;
using System.Text;

namespace NPlatform.Infrastructure.Consts
{
   public class EncryptCode
    {
        public const string AES = "aes.20210223";
    }
}
