### 产品名称： Not Platform
### 
### 作者：Dongliang Yi
### 基本说明：
 Not Platform 底层脚手架
 约束与规范了：
 applications
 DI
 Domains
 Repositories
 Result
 DTO


### 更新记录：
2022/1/5 迫于网络的痛苦，后续将迁移到 https://gitee.com/technical-seminar/notplatform
2021/9/8 NPlatform 底层脚手架 start！
